#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"

void startFork(int num)
{
    int pid = fork();

    if(pid == 0)
    {
        int i;
        for (i = 1; i <= num; i++)
        {
            printf(1, "High Priority: %d\n", i);
            sleep(7);
        }
    }
    else
    {
        int j;
        for (j = 1; j <= num; j++)
        {
            printf(1, "Low Priority: %d\n", j);
            sleep(10);
        }
    }
    wait();
}

int main(int argc, char* argv[])
{
    //Variables for the commandline arguments and character array comparisons
    int userNum = atoi(argv[1]);

    if (argc != 2)
    {
        printf(1, "USAGE: forkExecTest X \n");
    }
    else
    {
        if(userNum > 0)
        {
            printf(1, "You entered a correct argument. \n");
            startFork(userNum);
        }
        else
        {
            printf(1, "USAGE: X must be a valid positive integer");
        }
    }
    exit();
}