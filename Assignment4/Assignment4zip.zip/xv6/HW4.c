#include "types.h"
#include "fcntl.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int magic = getMagic();
    printf(1, "current magic number is the following: %d\n", magic);

    incrementMagic(3);

    magic = getMagic();
    printf(1, "current magic number is the following: %d\n", magic);

    printf(1, "current process name:");

    getCurrentProcessName();

    printf(1, "\n");

    modifyCurrentProcessName("newName");

    printf(1, "new process name:");

    getCurrentProcessName();

    printf(1, "\n");

    magic = getMagic();
    printf(1, "current magic number is the following: %d\n", magic);

    incrementMagic(3);

    magic = getMagic();
    printf(1, "current magic number is the following: %d\n", magic); 

    exit();
}