#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>

int main(int argc, char* argv[])
{
    //Variables for the start/stop/and total time
    clock_t start, end;
    double cpu_time;

    //Start the clock 
    start = clock();

    //Variables to store the minimum and maximum numbers
    int minNum = 0;
    int maxNum = 0;

    //Store the filename argument into a variable then read the file
    const char* filename = argv[1];
    FILE* ft = fopen(filename, "rb");
    if(ft) 
    {
        int pid = getpid();
        fseek (ft,0,SEEK_END); //go to end of file
        long size = ftell(ft); //what byte in file am I at?
        fseek (ft,0,SEEK_SET); //go to beginning of file
        int num = (int)size / (int)sizeof(int);
        printf("size of the file: %li ,sizeof(int) = %i\nthe number of numbers = %i\n\n", size, (int) sizeof(int), num);
        int i;
        for(i = 0; i < num; i++)
        {
            int temp = 0;
            fread(&temp,sizeof(int),1,ft);
            //printf("%i: %i\t",pid,temp);

            //Initialize the min/max number to the first number found
            if(i == 0)
            {
                minNum = temp;
                maxNum = temp;
            }

            //Call the min and max functions and set the variables.
            maxNum = max(maxNum, temp);
            minNum = min(minNum, temp);
        }
        fclose( ft ) ;
   }
   //Stop the time and calculate total time spent
   end = clock();
   cpu_time = ((double)(end-start))/CLOCKS_PER_SEC;

   printf("PID: %i\nThe maximum number: %i\n", getpid(), maxNum);
   printf("The minimum number: %i\nThis process took %f seconds to execute\n\n", minNum, cpu_time);

   return 0;
}

int max(int first, int second)
{
    if(first > second)
    {
        return first;
    }
    else
    {
        return second;
    }
}

int min(int first, int second)
{
    if(first < second)
    {
        return first;
    }
    else
    {
        return second;
    }
}