#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

void startFork(char* fileName)
{
    int pid;

    int i;
    //Loop through the four forks
    for (i = 0; i < 4; i++)
    {
        //Initialize the PID from the first fork
        pid = fork();

        //If the PID is zero it is a child, call execl
        if(pid == 0)
        {
            execl("minMax", "1", fileName, NULL);
        }
        //Else it is a parent so wait
        else
        {
            wait();
        }
    }
}

int main(int argc, char* argv[])
{
    printf("Trevor Barker\n");

    //Variables for the commandline arguments and character array comparisons
    char* numForks = argv[1];
    char* fileName = argv[2];
    char* one = "1";
    char* four = "4";

    if (argc != 3)
    {
        printf("USAGE: Assignment3 numForks fileName \n");
    }
    else
    {
        if(strcmp(numForks, one) == 0)
        {
            execl("minMax", "1", fileName, NULL);
        }
        else if(strcmp(numForks, four) == 0)
        {
            startFork(fileName);
        }
        else
        {
            printf("USAGE: numForks must be 1 or 4 \n");
        }
        
    }
    
}

