//This program just prints something to the screen
#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"

int
main (void)
{
    printf(1, "Trevor Barker\n");
    
    int fileName = open("tom.txt", O_RDWR | O_CREATE);
    if(fileName < 0)
    {
       return 1;
    }
    else
    {
        write(fileName,"1, 2, 3, 4\n", 36);
    }
    close(fileName);
    exit();
}
